package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var prefs: SharedPreferences
    private lateinit var tts: TextToSpeech
    private val history = JSONArray()
    private val voiceRequest = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("nova", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("Nova", "Online. I’m ready. Ask me anything or say a command.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(com.nova.assistant.R.drawable.bg); setPadding(18, 16, 18, 12) }
        val title = TextView(this).apply { text = "NOVA AI"; textSize = 26f; setTextColor(0xFFFFB300.toInt()); gravity = Gravity.CENTER; setPadding(0, 8, 0, 14) }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 4, 4, 8) }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 6, 0, 6) }
        listOf("YouTube", "Chrome", "Maps").forEach { name ->
            val b = Button(this).apply { text = name; setTextColor(0xFFFFB300.toInt()); setOnClickListener { openKnownApp(name) } }
            quick.addView(b, LinearLayout.LayoutParams(0, 48, 1f))
        }
        root.addView(quick)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "Ask Nova..."; setHintTextColor(0xFF777777.toInt()); setTextColor(0xFFFFFFFF.toInt()); setSingleLine(true); setBackgroundResource(com.nova.assistant.R.drawable.panel); setPadding(16, 0, 16, 0) }
        row.addView(input, LinearLayout.LayoutParams(0, 58, 1f))
        val mic = Button(this).apply { text = "🎤"; setOnClickListener { listen() } }
        row.addView(mic, LinearLayout.LayoutParams(64, 58))
        val send = Button(this).apply { text = "SEND"; setOnClickListener { send() } }
        row.addView(send, LinearLayout.LayoutParams(86, 58))
        root.addView(row)
        setContentView(root)
    }

    private fun addMessage(who: String, msg: String) {
        val tv = TextView(this).apply {
            text = "$who\n$msg"; textSize = 16f; setTextColor(if (who == "Nova") 0xFFFFFFFF.toInt() else 0xFFE0E0E0.toInt()); setPadding(16, 14, 16, 14); setBackgroundResource(com.nova.assistant.R.drawable.panel)
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 7, 0, 7); chat.addView(tv, lp)
    }

    private fun send() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        input.text.clear(); addMessage("You", text)
        thread {
            val reply = callGemini(text)
            runOnUiThread { addMessage("Nova", reply); speak(reply); executeAction(reply) }
        }
    }

    private fun callGemini(userText: String): String {
        val key = prefs.getString("gemini_key", "") ?: ""
        if (key.isBlank()) return "Set your Gemini API key first by adding it to Nova settings in the next version. For this build, put GEMINI_API_KEY in local app setup or edit MainActivity.kt before release."
        return try {
            val prompt = "You are Nova, an Android AI assistant. Be concise. If the user asks to open YouTube, Chrome, Maps, Gmail, WhatsApp, Spotify or Settings, append exactly one action tag such as [ACTION:OPEN:YouTube]. For phone calls use [ACTION:CALL:number], but never claim a call happened. User: $userText"
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"; conn.setRequestProperty("Content-Type", "application/json"); conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
            val response = conn.inputStream.bufferedReader().readText(); conn.disconnect()
            JSONObject(response).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { "I couldn't reach the AI service: ${e.message}" }
    }

    private fun executeAction(text: String) {
        val m = Regex("\\[ACTION:OPEN:([^]]+)]").find(text) ?: return
        openKnownApp(m.groupValues[1])
    }

    private fun openKnownApp(name: String) {
        val pkg = when (name.lowercase(Locale.US)) {
            "youtube" -> "com.google.android.youtube"
            "chrome" -> "com.android.chrome"
            "maps" -> "com.google.android.apps.maps"
            "gmail" -> "com.google.android.gm"
            "whatsapp" -> "com.whatsapp"
            "spotify" -> "com.spotify.music"
            "settings" -> null
            else -> null
        }
        try {
            val intent = if (name.equals("settings", true)) Intent(android.provider.Settings.ACTION_SETTINGS) else packageManager.getLaunchIntentForPackage(pkg ?: "")
            if (intent != null) startActivity(intent) else Toast.makeText(this, "$name isn't installed", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "Couldn't open $name", Toast.LENGTH_SHORT).show() }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 500); return }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Nova") }
        startActivityForResult(i, voiceRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) input.setText(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: "").also { send() }
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale.US }
    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text.replace(Regex("\\[ACTION:[^]]+]") , ""), TextToSpeech.QUEUE_FLUSH, null, "nova") }
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
