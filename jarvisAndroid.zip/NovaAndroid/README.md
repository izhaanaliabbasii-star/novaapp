# Nova AI — Android

Android rewrite of the Windows Nova/JARVIS project.

## What changed
The original desktop app depends on PyQt6, Windows APIs, PowerShell, pyautogui, pywinauto, pycaw, win10toast and other desktop-only packages. Those are not copied into Android. This project replaces the desktop shell with native Android UI, microphone speech recognition, Android app intents and text-to-speech.

## Build on GitHub
1. Upload this folder to a GitHub repository.
2. Push to `main`.
3. Open **Actions → Build Nova Android APK**.
4. Download the `nova-debug-apk` artifact.

## AI key
Do **not** commit a Gemini API key to GitHub. The current starter build expects a key stored locally. For a public release, move AI calls behind your own secure backend rather than shipping a provider key inside the APK.

## Project
`app/src/main/java/com/nova/assistant/MainActivity.kt` is the Android replacement for the Windows desktop entry point.
