package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Wraps Android's built-in SpeechRecognizer (speech -> text)
 * and TextToSpeech (text -> speech). No extra cost, works offline for TTS.
 */
class VoiceEngine(
    private val context: Context,
    private val onReadyCallback: () -> Unit,
    private val onListeningCallback: () -> Unit,
    private val onHeardCallback: (String) -> Unit,
    private val onErrorCallback: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /** True while the mic is actively listening. Used to avoid mic conflicts. */
    @Volatile
    var isListening: Boolean = false
        private set

    /** Callbacks waiting for a specific spoken reply to finish. */
    private val pendingAfter = HashMap<String, () -> Unit>()

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) {}
                    override fun onDone(id: String?) {
                        id?.let { pendingAfter.remove(it)?.invoke() }
                    }
                })
                mainHandler.post { onReadyCallback() }
            } else {
                mainHandler.post { onErrorCallback("Voice output failed to start") }
            }
        }
    }

    private fun ensureRecognizer() {
        if (recognizer != null) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onErrorCallback("Speech recognition not available on this device. Install or enable the Google app.")
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    mainHandler.post { onListeningCallback() }
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        mainHandler.post { onHeardCallback(matches[0]) }
                    } else {
                        mainHandler.post { onErrorCallback("I didn't catch that. Try again.") }
                    }
                }

                override fun onError(error: Int) {
                    isListening = false
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH ->
                            "Didn't understand that. Tap Talk and try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "I didn't hear anything. Tap Talk and speak."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Speech recognition needs internet. Turn on wifi/mobile data."
                        SpeechRecognizer.ERROR_AUDIO ->
                            "Mic is busy. Another app may be using it — try again."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Microphone permission is missing. Allow it in Settings > Apps > Nova."
                        SpeechRecognizer.ERROR_CLIENT ->
                            "Voice service hiccup. Tap Talk again."
                        else -> "Mic error (" + error + "). Try again."
                    }
                    mainHandler.post { onErrorCallback(msg) }
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private var utteranceCounter = 0

    fun listen() {
        ensureRecognizer()
        if (isListening) return              // don't start twice -> no stuck mic
        val rec = recognizer
        if (rec == null) {                   // recognition unavailable -> never get "stuck"
            onErrorCallback("Speech recognition is not available on this device.")
            return
        }
        tts?.stop()                          // interrupt any reply
        pendingAfter.clear()                 // drop callbacks of the interrupted reply
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Nova")
            // Android's default silence wait is ~2000ms before it decides you're
            // done talking — that alone eats most of a "3 second like Siri" budget.
            // Trimming it down makes Nova respond noticeably faster after you stop
            // speaking, at the small cost of cutting off someone who pauses mid-sentence.
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 900)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 700)
            putExtra("android.speech.extra.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", 1500)
            // Try on-device recognition first where supported — skips a network
            // round trip entirely for the speech-to-text step (falls back to
            // Google's online recognizer automatically if offline isn't available).
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try {
            rec.startListening(intent)       // can throw if called too fast after a stop
            isListening = true
        } catch (e: Exception) {
            isListening = false
            mainHandler.post {
                onErrorCallback("Voice service is busy. Wait a second and try again.")
            }
        }
    }

    /** Speak a reply. [after] runs when the reply finishes speaking. */
    fun speak(text: String, after: (() -> Unit)? = null) {
        mainHandler.post {
            utteranceCounter += 1
            val id = "nova_" + utteranceCounter
            if (after != null) pendingAfter[id] = after
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        }
    }

    fun shutdown() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}
