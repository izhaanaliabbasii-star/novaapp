package com.nova.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar
import java.util.Locale
import java.util.regex.Pattern

/**
 * "remind me to X in N minutes/hours" or "remind me to X at H(:MM)(am/pm)"
 * Schedules a one-shot alarm that fires ReminderReceiver, which posts a
 * notification and speaks the reminder if the app is in the foreground.
 */
object ReminderManager {

    private var counter = 100

    fun tryHandle(ctx: Context, raw: String): String? {
        val t = raw.lowercase(Locale.ROOT).trim()
        if (!t.startsWith("remind me")) return null

        // "remind me to <task> in <N> minutes/hours"
        val inMatch = Pattern.compile("remind me (?:to )?(.*?) in (\\d+)\\s*(minute|minutes|min|hour|hours|hr)")
            .matcher(t)
        if (inMatch.find()) {
            val task = inMatch.group(1)?.trim().takeUnless { it.isNullOrBlank() } ?: "your reminder"
            val amount = inMatch.group(2)!!.toInt()
            val unit = inMatch.group(3)!!
            val minutes = if (unit.startsWith("hour") || unit == "hr") amount * 60 else amount
            val triggerAt = System.currentTimeMillis() + minutes * 60_000L
            schedule(ctx, task, triggerAt)
            return "Okay, I'll remind you to $task in $amount ${if (unit.startsWith("hour") || unit == "hr") "hour(s)" else "minute(s)"}."
        }

        // "remind me to <task> at <H(:MM)> (am/pm)"
        val atMatch = Pattern.compile("remind me (?:to )?(.*?) at (\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?")
            .matcher(t)
        if (atMatch.find()) {
            val task = atMatch.group(1)?.trim().takeUnless { it.isNullOrBlank() } ?: "your reminder"
            var hour = atMatch.group(2)!!.toInt()
            val minute = atMatch.group(3)?.toInt() ?: 0
            val ampm = atMatch.group(4)
            if (ampm == "pm" && hour < 12) hour += 12
            if (ampm == "am" && hour == 12) hour = 0

            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }
            if (cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1) // already passed today -> tomorrow
            }
            schedule(ctx, task, cal.timeInMillis)
            val timeStr = String.format(Locale.US, "%02d:%02d", hour, minute)
            return "Okay, I'll remind you to $task at $timeStr."
        }

        return "Tell me when — like \"remind me to call mom in 20 minutes\" or \"remind me to leave at 5pm\"."
    }

    private fun schedule(ctx: Context, task: String, triggerAtMillis: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_TASK, task)
        }
        val requestCode = counter++
        val pi = PendingIntent.getBroadcast(
            ctx, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                // fall back to inexact if the user hasn't granted exact-alarm permission
                am.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }
}
