package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.speech.tts.TextToSpeech
import android.telecom.Call
import android.telecom.CallScreeningService
import java.util.Locale

/**
 * Auto-cuts calls that your CARRIER or Android's own caller ID has already
 * labeled as spam/scam (e.g. shows up as "Scam Likely", "Spam Risk",
 * "Suspected Fraud" as the caller name) — checks for those keywords in the
 * caller's displayed name and rejects automatically, announcing "Scam call
 * detected, call cut" out loud.
 *
 * For numbers with NO such label (just unrecognized, not flagged by
 * anyone), it only warns via notification — it does NOT auto-cut those,
 * since "not in my contacts" alone would wrongly block delivery drivers,
 * doctors' offices, new numbers, etc.
 *
 * HONEST LIMIT: this depends entirely on your carrier/phone already
 * attaching a spam label to the call before it reaches this code — Nova
 * has no spam database of its own. Whether a number gets labeled this way
 * varies by carrier and country; some carriers label very few numbers.
 *
 * To activate: Settings > Apps > Default apps > Caller ID & spam protection
 * (or Nova's "Enable spam call flagging" button) -> select Nova. Android
 * only allows ONE app to hold this role at a time.
 */
class SpamCallScreeningService : CallScreeningService() {

    companion object {
        private const val CHANNEL_ID = "nova_spam"
    }

    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart
        val callerLabel = callDetails.callerDisplayName ?: ""

        val spamKeywords = listOf("spam", "scam", "fraud", "robocall", "telemarket", "suspected")
        val labeledAsSpam = spamKeywords.any { callerLabel.contains(it, ignoreCase = true) }

        if (labeledAsSpam) {
            // The carrier/Android's own caller ID already flagged this number by name
            // (e.g. "Scam Likely", "Spam Risk") — this is a real signal, not a guess.
            respondToCall(
                callDetails,
                CallResponse.Builder()
                    .setDisallowCall(true)
                    .setRejectCall(true)
                    .setSkipNotification(false)
                    .build()
            )
            announceSpamCut(number ?: callerLabel, callerLabel)
            notifyPossibleSpam(number ?: callerLabel)
            return
        }

        // Not labeled as spam by the carrier — let it through. We no longer auto-cut
        // just for being unrecognized, since "not in my contacts" alone has too many
        // false positives (delivery drivers, doctors, new numbers, etc).
        respondToCall(callDetails, CallResponse.Builder().build())

        if (number != null) {
            val knownContact = ContactLookup.findNumber(this, number) != null || isNumberSaved(number)
            if (!knownContact) {
                notifyPossibleSpam(number) // warn only, doesn't cut
            }
        }
    }

    private fun announceSpamCut(number: String, label: String) {
        val spoken = if (label.isNotBlank()) {
            "Scam call detected, labeled $label. Call cut."
        } else {
            "Spam call from $number, call cut."
        }
        var tts: TextToSpeech? = null
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "nova_spam_cut")
            }
        }
    }

    private fun isNumberSaved(number: String): Boolean {
        // ContactLookup matches by name, not number -> do a lightweight reverse check
        return try {
            val cursor = contentResolver.query(
                android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI
                    .buildUpon().appendPath(number).build(),
                arrayOf(android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            val found = cursor?.use { it.moveToFirst() } ?: false
            found
        } catch (e: Exception) {
            true // if we can't check, don't falsely flag as spam
        }
    }

    private fun notifyPossibleSpam(number: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Possible spam calls", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Possible spam call")
            .setContentText("Incoming call from $number — not in your contacts.")
            .setSmallIcon(R.drawable.ic_launcher)
            .setAutoCancel(true)
            .build()
        nm.notify(number.hashCode(), notification)
    }
}
