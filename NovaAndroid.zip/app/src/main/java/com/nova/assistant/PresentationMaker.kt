package com.nova.assistant

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * "make a presentation about electric cars, 30 slides"
 *
 * 1. Gemini writes the slide content as JSON
 * 2. This class builds a real .pptx file from scratch (PPTX = ZIP of XML,
 *    no PC and no heavy libraries needed) with a design theme
 * 3. Saved to Downloads and opened for you
 *
 * Designs: 12 palettes x light/dark x 3 layouts x 4 accent shifts x 5 heading
 * fonts = 1,440 design combos, picked by the topic so the same topic always
 * looks the same.
 */
object PresentationMaker {

    // ---- 12 color palettes: Pair(accentColor, backgroundColor) ----
    private val PALETTES = listOf(
        Triple("7C4DFF", "FFFFFF", "121212"), // violet
        Triple("00BFA5", "FFFFFF", "0B2622"), // teal
        Triple("FF6D00", "FFFFFF", "241105"), // orange
        Triple("2962FF", "FFFFFF", "0A1330"), // blue
        Triple("D50000", "FFFFFF", "2A0808"), // red
        Triple("00C853", "FFFFFF", "06220F"), // green
        Triple("C51162", "FFFFFF", "2B0718"), // pink
        Triple("FFD600", "111111", "1A1800"), // yellow
        Triple("00B8D4", "FFFFFF", "04222A"), // cyan
        Triple("651FFF", "FFFFFF", "150B2E"), // deep purple
        Triple("3E2723", "FFFFFF", "F5F0EC"), // brown-cream
        Triple("263238", "FFFFFF", "ECEFF1")  // blue-grey
    )

    // ---- extra multipliers so palette x light/dark x layout x accent-shift x
    // heading-font stacks past 1,000 unique combos, deterministically from the topic ----
    private val LAYOUTS = 3
    private val ACCENT_SHIFTS = listOf(0, -24, 24, -48)   // darken/lighten accent %, 4 options
    private val HEADING_FONTS = listOf("Calibri", "Georgia", "Verdana", "Trebuchet MS", "Segoe UI") // 5 options
    // 12 palettes x 2 (light/dark) x 3 layouts x 4 accent shifts x 5 fonts = 1,440 combos

    /** Returns a spoken reply. Runs on a background thread (called from MainActivity). */
    fun handle(ctx: Context, geminiKey: String, raw: String): String {
        val t = raw.lowercase()

        // count slides
        var slides = 10
        val numMatch = Regex("(\\d+)\\s+slides?").find(t)
        if (numMatch != null) slides = numMatch.groupValues[1].toIntOrNull() ?: 10
        slides = slides.coerceIn(4, 40)

        // topic cleanup
        var topic = raw
            .replace(Regex("(?i)make|create|generate|prepare|a|an|the|presentation|presentations|" +
                "powerpoint|ppt|pptx|slides?|of|about|on|for|with|me|please"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (topic.isEmpty()) topic = "General Knowledge"

        // 1) content from Gemini (JSON)
        val prompt = "Create a presentation as STRICT JSON only (no markdown fences): " +
            "{\"title\": string, \"slides\": [{\"heading\": string, " +
            "\"bullets\": array of 3-5 short strings}]}. " +
            "Topic: " + topic + ". Exactly " + slides + " slides. " +
            "Slide 1 heading = the title. Short, punchy, presentation-ready text."
        val jsonText = GeminiClient.ask(geminiKey, prompt)
        val deck = parseDeck(jsonText, topic, slides)
            ?: return "Sorry, I couldn't build that deck. Try: make a presentation about space, 12 slides."

        // 2) design theme from topic hash — palette x light/dark x layout x
        // accent-shift x heading-font = 1,440 deterministic combos
        val hash = topic.hashCode()
        val palette = PALETTES[Math.floorMod(hash, PALETTES.size)]
        val dark = (hash / 7) % 2 == 0
        val layoutVariant = Math.floorMod(hash / 13, LAYOUTS)
        val accentShift = ACCENT_SHIFTS[Math.floorMod(hash / 41, ACCENT_SHIFTS.size)]
        val headingFont = HEADING_FONTS[Math.floorMod(hash / 97, HEADING_FONTS.size)]
        val design = Design(
            accent = shiftHex(palette.first, accentShift),
            bg = if (dark) palette.third else palette.second,
            text = if (dark) "F5F5F5" else "1A1A1A",
            layout = layoutVariant,
            headingFont = headingFont
        )

        // 3) build + save
        return try {
            val pptx = buildPptx(deck, design)
            val fileName = "nova_" + topic.replace(Regex("[^A-Za-z0-9]+"), "_")
                .lowercase().take(30) + ".pptx"
            val uri = saveToDownloads(ctx, fileName, pptx)
            if (uri != null) {
                openFile(ctx, uri)
                "Done! Your " + deck.length() + " slide presentation about " + topic +
                    " is saved in Downloads and opening now. Design: " +
                    (if (dark) "dark " else "light ") + "theme."
            } else "Built it but couldn't save. Check storage permission."
        } catch (e: Exception) {
            "Error building presentation: " + (e.message ?: "unknown")
        }
    }

    private fun parseDeck(jsonText: String, fallbackTitle: String, wantSlides: Int): JSONObject? {
        return try {
            var clean = jsonText.trim()
            if (clean.startsWith("```")) {
                clean = clean.removePrefix("```json").removePrefix("```")
                    .removeSuffix("```").trim()
            }
            val start = clean.indexOf('{')
            val end = clean.lastIndexOf('}')
            if (start < 0 || end <= start) return null
            val deck = JSONObject(clean.substring(start, end + 1))
            if (!deck.has("slides")) return null
            val arr = deck.getJSONArray("slides")
            // pad / trim to requested count so it never lies about slide numbers
            val fixed = JSONArray()
            for (i in 0 until wantSlides) {
                if (i < arr.length()) fixed.put(arr.getJSONObject(i))
                else fixed.put(JSONObject()
                    .put("heading", "Point " + (i + 1))
                    .put("bullets", JSONArray().put("Discuss key idea " + (i + 1))))
            }
            deck.put("slides", fixed)
            if (!deck.has("title")) deck.put("title", fallbackTitle)
            deck
        } catch (e: Exception) { null }
    }

    private class Design(
        val accent: String, val bg: String, val text: String,
        val layout: Int, val headingFont: String = "Calibri"
    )

    /** Lightens (positive %) or darkens (negative %) a hex color for extra palette variety. */
    private fun shiftHex(hex: String, percent: Int): String {
        if (percent == 0) return hex
        val r = hex.substring(0, 2).toInt(16)
        val g = hex.substring(2, 4).toInt(16)
        val b = hex.substring(4, 6).toInt(16)
        fun shift(c: Int): Int {
            val delta = (if (percent > 0) (255 - c) else c) * percent / 100
            return (c + delta).coerceIn(0, 255)
        }
        return "%02X%02X%02X".format(shift(r), shift(g), shift(b))
    }

    // ================= PPTX BUILDER =================
    private fun buildPptx(deck: JSONObject, d: Design): ByteArray {
        val slides = deck.getJSONArray("slides")
        val title = deck.getString("title")
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            fun add(name: String, xml: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(xml.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }

            add("[Content_Types].xml", contentTypes(slides.length()))
            add("_rels/.rels", rootRels())
            add("ppt/presentation.xml", presentationXml(slides.length()))
            add("ppt/_rels/presentation.xml.rels", presentationRels(slides.length()))
            add("ppt/slideMasters/slideMaster1.xml", slideMasterXml())
            add("ppt/slideMasters/_rels/slideMaster1.xml.rels", slideMasterRels())
            add("ppt/slideLayouts/slideLayout1.xml", slideLayoutXml())
            add("ppt/slideLayouts/_rels/slideLayout1.xml.rels", slideLayoutRels())
            add("ppt/theme/theme1.xml", themeXml(d.headingFont))
            add("docProps/core.xml", coreXml(title))
            add("docProps/app.xml", appXml())

            for (i in 0 until slides.length()) {
                val s = slides.getJSONObject(i)
                val heading = s.optString("heading", "Slide " + (i + 1))
                val bullets = s.optJSONArray("bullets") ?: JSONArray()
                add("ppt/slides/slide" + (i + 1) + ".xml",
                    slideXml(title = heading, bullets = bullets, d = d,
                        isTitleSlide = i == 0, slideNum = i + 1, total = slides.length()))
                add("ppt/slides/_rels/slide" + (i + 1) + ".xml.rels", slideRels())
            }
        }
        return out.toByteArray()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;")

    private fun contentTypes(n: Int): String {
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>" +
            "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>" +
            "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>" +
            "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>" +
            "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>" +
            "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>")
        for (i in 1..n) sb.append("<Override PartName=\"/ppt/slides/slide$i.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>")
        return sb.append("</Types>").toString()
    }

    private fun rootRels() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"ppt/presentation.xml\"/>" +
        "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
        "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>" +
        "</Relationships>"

    private fun presentationXml(n: Int): String {
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<p:presentation xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\">" +
            "<p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>")
        for (i in 1..n) sb.append("<p:sldId id=\"" + (255 + i) + "\" r:id=\"rId" + (i + 1) + "\"/>")
        sb.append("</p:sldIdLst><p:sldSz cx=\"12192000\" cy=\"6858000\"/>" +
            "<p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>")
        return sb.toString()
    }

    private fun presentationRels(n: Int): String {
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/>")
        for (i in 1..n) sb.append("<Relationship Id=\"rId" + (i + 1) + "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide\" Target=\"slides/slide$i.xml\"/>")
        return sb.append("</Relationships>").toString()
    }

    private fun slideMasterXml() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<p:sldMaster xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
        "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\">" +
        "<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
        "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>" +
        "</p:spTree></p:cSld>" +
        "<p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>" +
        "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst>" +
        "</p:sldMaster>"

    private fun slideMasterRels() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/>" +
        "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme\" Target=\"../theme/theme1.xml\"/>" +
        "</Relationships>"

    private fun slideLayoutXml() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<p:sldLayout xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
        "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\" type=\"blank\" preserve=\"1\">" +
        "<p:cSld name=\"Blank\"><p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
        "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>" +
        "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"

    private fun slideLayoutRels() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster\" Target=\"../slideMasters/slideMaster1.xml\"/>" +
        "</Relationships>"

    private fun slideRels() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/>" +
        "</Relationships>"

    private fun themeXml(headingFont: String) = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<a:theme xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" name=\"Nova\">" +
        "<a:themeElements><a:clrScheme name=\"Nova\">" +
        "<a:dk1><a:srgbClr val=\"000000\"/></a:dk1><a:lt1><a:srgbClr val=\"FFFFFF\"/></a:lt1>" +
        "<a:dk2><a:srgbClr val=\"1A1A1A\"/></a:dk2><a:lt2><a:srgbClr val=\"F5F5F5\"/></a:lt2>" +
        "<a:accent1><a:srgbClr val=\"7C4DFF\"/></a:accent1><a:accent2><a:srgbClr val=\"00BFA5\"/></a:accent2>" +
        "<a:accent3><a:srgbClr val=\"FF6D00\"/></a:accent3><a:accent4><a:srgbClr val=\"2962FF\"/></a:accent4>" +
        "<a:accent5><a:srgbClr val=\"D50000\"/></a:accent5><a:accent6><a:srgbClr val=\"00C853\"/></a:accent6>" +
        "<a:hlink><a:srgbClr val=\"2962FF\"/></a:hlink><a:folHlink><a:srgbClr val=\"7C4DFF\"/></a:folHlink>" +
        "</a:clrScheme><a:fontScheme name=\"Nova\"><a:majorFont><a:latin typeface=\"" + headingFont + "\"/>" +
        "<a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont><a:minorFont><a:latin typeface=\"Arial\"/>" +
        "<a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme><a:fmtScheme name=\"Nova\">" +
        "<a:fillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>" +
        "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:fillStyleLst>" +
        "<a:lnStyleLst><a:ln w=\"6350\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>" +
        "<a:ln w=\"12700\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>" +
        "<a:ln w=\"19050\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln></a:lnStyleLst>" +
        "<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle>" +
        "<a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>" +
        "<a:bgFillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>" +
        "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme>" +
        "</a:themeElements></a:theme>"

    private fun coreXml(title: String) = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
        "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>" + esc(title) +
        "</dc:title><dc:creator>Nova</dc:creator></cp:coreProperties>"

    private fun appXml() = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" " +
        "xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">" +
        "<Application>Nova Android</Application></Properties>"

    /** One slide = background color + text boxes (title + bullets). 3 layout variants. */
    private fun slideXml(title: String, bullets: JSONArray, d: Design,
                         isTitleSlide: Boolean, slideNum: Int, total: Int): String {
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<p:sld xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\"><p:cSld>" +
            "<p:bg><p:bgPr><a:solidFill><a:srgbClr val=\"" + d.bg + "\"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>" +
            "<p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
            "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>")

        if (isTitleSlide || d.layout == 2) {
            // centered big title slide
            sb.append(textBox(id = 2, name = "Title", x = 914400, y = 2286000,
                w = 10363200, h = 1600200, text = title, size = 4400, bold = true,
                color = d.accent, align = "ctr"))
            if (isTitleSlide && bullets.length() > 0) {
                sb.append(textBox(id = 3, name = "Sub", x = 1828800, y = 4114800,
                    w = 8534400, h = 914400, text = bullets.optString(0, ""),
                    size = 2400, bold = false, color = d.text, align = "ctr"))
            }
            sb.append(textBox(id = 4, name = "Num", x = 10668000, y = 6400800,
                w = 1000000, h = 320040, text = slideNum.toString() + " / " + total,
                size = 1200, bold = false, color = d.text, align = "r"))
        } else {
            // accent bar on the left
            sb.append("<p:sp><p:nvSpPr><p:cNvPr id=\"5\" name=\"Bar\"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>" +
                "<p:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"274320\" cy=\"6858000\"/></a:xfrm>" +
                "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val=\"" +
                d.accent + "\"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr><p:txBody>" +
                "<a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang=\"en-US\"/></a:p></p:txBody></p:sp>")
            val titleY = if (d.layout == 1) 548640 else 365760
            sb.append(textBox(id = 2, name = "Title", x = 731520, y = titleY,
                w = 10820400, h = 1005840, text = title, size = 3200, bold = true,
                color = d.accent, align = "l"))
            // bullets, one paragraph each
            val bulletText = StringBuilder()
            for (b in 0 until bullets.length()) {
                bulletText.append("• ").append(bullets.optString(b, ""))
                if (b < bullets.length() - 1) bulletText.append("\n")
            }
            sb.append(textBox(id = 3, name = "Body", x = 914400, y = titleY + 1280160,
                w = 10439400, h = 4343400, text = bulletText.toString(),
                size = 2000, bold = false, color = d.text, align = "l", multiLine = true))
            sb.append(textBox(id = 4, name = "Num", x = 10668000, y = 6400800,
                w = 1000000, h = 320040, text = slideNum.toString() + " / " + total,
                size = 1200, bold = false, color = d.text, align = "r"))
        }

        sb.append("</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>")
        return sb.toString()
    }

    private fun textBox(id: Int, name: String, x: Int, y: Int, w: Int, h: Int,
                        text: String, size: Int, bold: Boolean, color: String,
                        align: String, multiLine: Boolean = false): String {
        val lines = text.split("\n")
        val sb = StringBuilder("<p:sp><p:nvSpPr><p:cNvPr id=\"" + id + "\" name=\"" + name +
            "\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr><p:spPr>" +
            "<a:xfrm><a:off x=\"" + x + "\" y=\"" + y + "\"/><a:ext cx=\"" + w + "\" cy=\"" + h + "\"/></a:xfrm>" +
            "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/></p:spPr><p:txBody>" +
            "<a:bodyPr wrap=\"square\"/><a:lstStyle/>")
        for ((idx, line) in lines.withIndex()) {
            sb.append("<a:p><a:pPr algn=\"" + align + "\"><a:defRPr sz=\"" + size + "\"" +
                (if (bold) " b=\"1\"" else "") + "><a:solidFill><a:srgbClr val=\"" + color +
                "\"/></a:solidFill></a:defRPr></a:pPr>")
            if (line.isNotEmpty()) {
                sb.append("<a:r><a:rPr lang=\"en-US\" sz=\"" + size + "\"" +
                    (if (bold) " b=\"1\"" else "") + "><a:solidFill><a:srgbClr val=\"" +
                    color + "\"/></a:solidFill></a:rPr><a:t>" + esc(line) + "</a:t></a:r>")
            }
            sb.append("</a:p>")
        }
        sb.append("</p:txBody></p:sp>")
        return sb.toString()
    }

    // ================= SAVE + OPEN =================
    private fun saveToDownloads(ctx: Context, fileName: String, bytes: ByteArray): Uri? {
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Files.FileColumns.DISPLAY_NAME, fileName)
                put(MediaStore.Files.FileColumns.MIME_TYPE,
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation")
                put(MediaStore.Files.FileColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/Nova")
            }
            val uri = ctx.contentResolver.insert(
                MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
            if (uri == null) return null
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return null
            uri
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val f = java.io.File(dir, fileName)
            f.writeBytes(bytes)
            Uri.fromFile(f)
        }
    }

    private fun openFile(ctx: Context, uri: Uri) {
        try {
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri,
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(view, "Open presentation").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Saved in Downloads/Nova — no PowerPoint app found.",
                Toast.LENGTH_LONG).show()
        }
    }
}
