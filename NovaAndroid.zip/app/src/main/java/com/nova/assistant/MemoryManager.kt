package com.nova.assistant

import android.content.Context
import org.json.JSONObject

/**
 * Long-term fact memory. "remember X" stores a free-text fact under a key
 * guessed from the sentence; "what do you remember about X" / "do you
 * remember X" recalls it. Backed by SharedPreferences (a single JSON blob),
 * so it survives app restarts.
 */
object MemoryManager {

    private const val PREFS = "nova_memory"
    private const val KEY_FACTS = "facts_json"

    private fun facts(ctx: Context): JSONObject {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_FACTS, "{}") ?: "{}"
        return try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
    }

    private fun save(ctx: Context, obj: JSONObject) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_FACTS, obj.toString())
            .apply()
    }

    /** Stores raw text under a numbered slot, so nothing ever overwrites silently. */
    fun remember(ctx: Context, fact: String): String {
        val obj = facts(ctx)
        val nextId = obj.length()
        obj.put("fact_$nextId", fact.trim())
        save(ctx, obj)
        return "Got it, I'll remember that."
    }

    /** Very simple keyword search across stored facts. */
    fun recall(ctx: Context, query: String): String {
        val obj = facts(ctx)
        if (obj.length() == 0) return "I don't have anything remembered yet."
        val words = query.lowercase().split(" ").filter { it.length > 2 }
        var best: String? = null
        var bestScore = 0
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val text = obj.optString(k, "")
            val score = words.count { text.lowercase().contains(it) }
            if (score > bestScore) { bestScore = score; best = text }
        }
        return if (best != null) best else "I don't remember anything about that."
    }

    fun listAll(ctx: Context): String {
        val obj = facts(ctx)
        if (obj.length() == 0) return "I don't have anything remembered yet."
        val items = mutableListOf<String>()
        val keys = obj.keys()
        while (keys.hasNext()) items.add(obj.optString(keys.next(), ""))
        return "Here's what I remember: " + items.joinToString("; ")
    }

    fun forgetAll(ctx: Context): String {
        save(ctx, JSONObject())
        return "Cleared everything I remembered."
    }
}
