package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Always-listening "Nova" wake word using Android's OWN built-in speech
 * recognizer in a loop — no Picovoice account, no company email, no .ppn
 * file, no signup of any kind required.
 *
 * How it works: keeps restarting short listening sessions and checks each
 * one for the word "nova". Slightly more battery use than a dedicated
 * wake-word engine, and needs network for recognition on most phones, but
 * needs ZERO setup beyond installing the app.
 *
 * IMPORTANT: call pause() while Nova is listening/speaking, resume() after.
 * Two things grabbing the mic at once = "he pauses and doesn't answer".
 */
class WakeWordManager(
    private val context: Context,
    private val onWake: () -> Unit,
    private val onError: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var paused = false

    /** Stop reacting to the wake word (mic still held, but ignored). */
    fun pause() { paused = true }

    /** Start reacting to the wake word again. */
    fun resume() { paused = false }

    fun start() {
        if (running) return
        running = true
        handler.post { listenOnce() }
    }

    fun stop() {
        running = false
        handler.post {
            recognizer?.destroy()
            recognizer = null
        }
    }

    private fun listenOnce() {
        if (!running) return

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition not available on this device")
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.lowercase()
                        .orEmpty()
                    if (!paused && (text.contains("nova") || text.contains("hey nova"))) {
                        onWake()
                    }
                    restartSoon()
                }

                override fun onError(error: Int) {
                    // No speech / timeout is normal in a listening loop — just restart quietly.
                    restartSoon()
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 600)
                putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 500)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }

            if (!paused) startListening(intent)
        }
    }

    private fun restartSoon() {
        // Small gap avoids hammering the recognizer service back-to-back.
        handler.postDelayed({ if (running) listenOnce() }, 300)
    }
}
