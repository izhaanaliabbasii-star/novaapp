package com.nova.assistant

/** Shared "end the conversation" detection so continuous listening knows when to stop. */
object ConversationUtil {

    private val EXIT_PHRASES = listOf(
        "stop", "that's all", "thats all", "that's it", "thats it",
        "nevermind", "never mind", "goodbye", "good bye", "bye", "bye nova",
        "quiet", "ok stop", "okay stop", "shut up", "cancel", "never mind that"
    )

    fun isExitPhrase(text: String): Boolean {
        val t = text.trim().lowercase()
        return EXIT_PHRASES.any { t == it || t.startsWith("$it ") || t.endsWith(" $it") }
    }
}
