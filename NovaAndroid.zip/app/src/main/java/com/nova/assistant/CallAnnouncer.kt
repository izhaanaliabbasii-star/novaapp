package com.nova.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import android.telephony.TelephonyManager
import java.util.Locale

/**
 * Announces "Incoming call from <name/number>" out loud when the phone rings,
 * using the normal PHONE_STATE broadcast every app is allowed to read.
 *
 * IMPORTANT — honest limit: this can only ANNOUNCE the call. It cannot answer,
 * decline, or put the call on speaker — those actions require the app to be
 * the phone's default dialer, which needs a Google Play review and can't be
 * done by a sideloaded APK. This receiver never tries to touch the call itself.
 */
class CallAnnouncer : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val name = number?.let { ContactLookup.findName(context, it) }

        val toSay = when {
            !name.isNullOrBlank() -> "Incoming call from $name"
            !number.isNullOrBlank() -> "Incoming call from $number"
            else -> "You have an incoming call"
        }

        // Short-lived TTS instance just for this announcement — the app doesn't
        // need to be open for this to speak.
        var tts: TextToSpeech? = null
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.speak(toSay, TextToSpeech.QUEUE_FLUSH, null, "nova_call_announce")
            }
        }
    }
}
